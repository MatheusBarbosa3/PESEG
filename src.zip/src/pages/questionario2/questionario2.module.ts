import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Questionario2Page } from './questionario2';

@NgModule({
  declarations: [
    Questionario2Page,
  ],
  imports: [
    IonicPageModule.forChild(Questionario2Page),
  ],
})
export class Questionario2PageModule {}
