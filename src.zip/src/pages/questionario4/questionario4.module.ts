import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Questionario4Page } from './questionario4';

@NgModule({
  declarations: [
    Questionario4Page,
  ],
  imports: [
    IonicPageModule.forChild(Questionario4Page),
  ],
})
export class Questionario4PageModule {}
