import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Questionario2Page } from '../questionario2/questionario2';

@IonicPage()
@Component({
  selector: 'page-questionario',
  templateUrl: 'questionario.html',
})
export class QuestionarioPage {

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  btnProximo() {
    
    this.navCtrl.push(Questionario2Page); 
  }    

  ionViewDidLoad() {
    console.log('ionViewDidLoad QuestionarioPage');
  }

}
