import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Questionario3Page } from './questionario3';

@NgModule({
  declarations: [
    Questionario3Page,
  ],
  imports: [
    IonicPageModule.forChild(Questionario3Page),
  ],
})
export class Questionario3PageModule {}
